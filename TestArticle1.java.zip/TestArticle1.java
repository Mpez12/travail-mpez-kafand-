package bac3ig;
import java.util.Scanner;
import java.util.Hashtable;
import java.util.Map;
public class TestArticle1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<String, String> stock = new Hashtable<String, String>();
		Scanner lect = new Scanner(System.in);
		stock.put("032", "COWBEL");
		stock.put("002", "MILKIT");
		stock.put("003", "MELEKI");
		stock.put("004", "HUILE");
		stock.put("005", "KUNG FU");
		stock.put("006", "KOMBAT");
		stock.put("007", "BORA");
		stock.put("008", "DJINO");
		stock.put("009", "WORLD COLA");
		stock.put("010", "BIG");
		stock.put("011", "SUCRE");
		stock.put("012", "LAIT");
		stock.put("013", "STYLO");
		stock.put("014", "CAHIER");
		stock.put("015", "PENTALON");
		stock.put("016", "T-SHIRT");
		stock.put("017", "CASQUETTE");
		stock.put("018", "CRAYON");
		stock.put("019", "CANETTE");
		stock.put("020", "GOMME");
		System.out.println(" entre soit le code de l'article ou le nom de l'article : ");
		String rech = lect.next();
		for (Map.Entry mapentry : stock.entrySet()) {
			if (mapentry.getValue().equals(rech) || mapentry.getKey().equals(rech))
				System.out.println("cle : " + mapentry.getKey() + " | valeur : " + mapentry.getValue());
		}

	}

}
